/**
 * 
 */
/**
 * 
 */
module ShopManagementSystem {
}