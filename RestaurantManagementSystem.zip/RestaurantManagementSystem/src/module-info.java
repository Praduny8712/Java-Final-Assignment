/**
 * 
 */
/**
 * 
 */
module RestaurantManagementSystem {
}