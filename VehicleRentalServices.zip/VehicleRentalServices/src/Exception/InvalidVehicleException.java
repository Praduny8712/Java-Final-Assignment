package Exception;

public class InvalidVehicleException extends Exception {
	
	    public InvalidVehicleException(String message) {
	        super(message);
	    }
	}

